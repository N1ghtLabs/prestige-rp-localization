export const cases = {
    title: {
        ru: 'Кейсы',
        ua: 'Кейси',
        en: 'Cases',
        de: 'Kisten',
        pl: 'Etui',
        zh: '玩具箱',
    },
    text: {
        ru: 'Здесь вы можете попытать удачу, открывая кейсы с различными призами. Вы можете как получить намного более ценные вещи за меньшую цену, так же и остаться в минусе. Удачи!',
        ua: 'Тут ви можете спробувати щастя, відкриваючи кейси з різними призами. Ви можете як отримати значно цінніші речі за меншу ціну, так і залишитися в мінусі. Успіхів!',
        en: 'Here you can try your luck by opening cases with various prizes. You can either get much more valuable items for a lower price, or you can end up in the red. Good luck!',
        de: 'Hier kannst du dein Glück versuchen, indem du Kisten mit verschiedenen Preisen öffnest. Du kannst entweder viel wertvollere Gegenstände für einen niedrigeren Preis erhalten oder im Minus landen. Viel Glück!',
        pl: 'Tutaj możesz spróbować szczęścia, otwierając etui z różnymi nagrodami. Możesz zarówno otrzymać znacznie cenniejsze przedmioty za niższą cenę, jak i pozostać na minusie. Powodzenia!',
        zh: '在这里，你可以打开各种奖品的箱子试试运气。你要么能以更低的价格买到更有价值的东西，要么最终会亏损。祝你好运',
    },

    warning: {
        ru: 'Внимание! При продаже призов из этого кейса их цена будет 0 Olymp-Coins',
        ua: 'Увага! При продажу призів із цього кейса їхня ціна буде 0 Olymp-Coins',
        en: 'Warning! When selling prizes from this case, their price will be 0 Olymp-Coins',
        de: 'Achtung! Beim Verkauf von Preisen aus dieser Kiste beträgt dein Preis 0 Olymp-Coins',
        pl: `Uwaga! Przy sprzedaży nagród z tego case'u ich cena wyniesie 0 Olymp-Coins`,
    },

    notEnough: {
        ru: 'У вас нет этих кейсов.',
        ua: 'У вас немає таких кейсів.',
        en: "You don't have these cases.",
        de: 'Du hast diese Kisten nicht.',
        pl: 'Nie masz tych skrzynek.',
        zh: '你没有盒子',
    },

    back: {
        ru: 'Вернуться к кейсам',
        ua: 'Повернутися до кейсів',
        en: 'Go back to cases',
        de: 'Zurück zu den Kisten',
        pl: 'Wróć do skrzynek',
        zh: '回到盒子里去',
    },
    openCases: {
        ru: 'Открыть кейсов',
        ua: 'Відкрити кейсів',
        en: 'Open cases',
        de: 'Kiste öffnen',
        pl: 'Otwórz skrzynki',
        zh: '打开盒子',
    },
    openCase: {
        ru: 'Открыть кейс',
        ua: 'Відкрити кейс',
        en: 'Open case',
        de: 'Kiste öffnen',
        pl: 'Otwórz skrzynkę',
        zh: '打开盒子',
    },
    openCasesQuantity: {
        ru: 'Открыть кейсы: {{quantity}} шт.',
        ua: 'Відкрити кейси: {{quantity}} шт.',
        en: 'Open cases: {{quantity}} pcs.',
        de: 'Kisten öffnen: {{quantity}} Stk.',
        pl: 'Otwórz skrzynki: {{quantity}} szt.',
        zh: '打开盒子: {{quantity}}',
    },
    opening: {
        ru: 'Открываем кейс...',
        ua: 'Відкриваємо кейс...',
        en: 'Opening case...',
        de: 'Öffne Kiste...',
        pl: 'Otwieram skrzynek...',
        zh: '打开盒子',
    },
    buyCases: {
        ru: 'Приобрести кейсы',
        ua: 'Придбати кейси',
        en: 'Buy cases',
        de: 'Kiste kaufen',
        pl: 'Kup skrzynki',
        zh: '购买箱子',
    },
    buyCaseQuantity: {
        ru: 'Количество кейсов к покупке',
        ua: 'Кількість кейсів для покупки',
        en: 'Quantity of cases to buy',
        de: 'Anzahl der zu kaufenden Kiste',
        pl: 'Ilość skrzynek do kupienia',
        zh: '购买盒子的数量',
    },
    buy: {
        ru: 'Купить',
        ua: 'Купити',
        en: 'Buy',
        de: 'Kaufen',
        pl: 'Kup',
        zh: '购买',
    },
    fastOpening: {
        ru: 'Быстрое открытие',
        ua: 'Швидке відкриття',
        en: 'Quick opening',
        de: 'Schnelles Öffnen',
        pl: 'Szybkie otwieranie',
        zh: '快速打开',
    },
    possiblePrizes: {
        ru: 'Возможные призы',
        ua: 'Можливі призи',
        en: 'Possible prizes',
        de: 'Mögliche Preise',
        pl: 'Możliwe nagrody',
        zh: '可能的奖品',
    },
    yourCasesQuantity: {
        ru: 'У вас {{quantity}} шт.',
        ua: 'У вас {{quantity}} шт.',
        en: 'You have {{quantity}} pcs.',
        de: 'Du hast {{quantity}} Stk.',
        pl: 'Masz {{quantity}} szt.',
        zh: '你有的盒子数量',
    },

    categories: {
        vehicles: {
            ru: 'Транспорт',
            ua: 'Транспорт',
            en: 'Vehicles',
            de: 'Fahrzeuge',
            pl: 'Pojazdy',
            zh: '车辆',
        },
        clothes: {
            ru: 'Одежда',
            ua: 'Одяг',
            en: 'Clothes',
            de: 'Kleidung',
            pl: 'Ubrania',
            zh: '衣服',
        },
        currency: {
            ru: 'Валюта',
            ua: 'Валюта',
            en: 'Currency',
            de: 'Währung',
            pl: 'Waluta',
            zh: '货币',
        },
        donate: {
            en: 'Olymp-Coins',
        },
        other: {
            ru: 'Разное',
            ua: 'Різне',
            en: 'Other',
            de: 'Andere',
            pl: 'Inne',
            zh: '其他',
        },
        exclusive: {
            ru: 'Эксклюзивные',
            ua: 'Ексклюзивні',
            en: 'Exclusive',
            de: 'Exklusiv',
            pl: 'Ekskluzywne',
            zh: '独家',
        },
    },

    cases: {
        bmw: {
            name: {
                ru: 'Бумер',
                ua: 'Бумер',
                en: 'BMW',
                de: 'BMW',
                pl: 'BMW',
                zh: 'BMW',
            },
            desc: {
                ru: 'Кажется, мы нашли рай для всех любителей BMW. Для тех, кто не хочет выбирать между скоростью, комфортом и возможностью подрифтить. BMW - это когда у тебя есть всё и сразу.',
                ua: 'Здається, ми знайшли рай для всіх любителів BMW. Для тих, хто не хоче вибирати між швидкістю, комфортом і можливістю подрифтувати. BMW - це коли у тебе є все і одразу.',
                en: "It seems we've found paradise for all BMW lovers. For those who don't want to choose between speed, comfort and the ability to drift. BMW - this is when you have everything at once.",
                de: 'Es scheint, als hätten wir das Paradies für alle BMW-Liebhaber gefunden. Für diejenigen, die sich nicht zwischen Geschwindigkeit, Komfort und der Möglichkeit entscheiden wollen, einen Drift hinzulegen. BMW - das ist, wenn man alles gleichzeitig hat.',
                pl: 'Wygląda na to, że znaleźliśmy raj dla wszystkich miłośników BMW. Dla tych, którzy nie chcą wybierać między prędkością, komfortem a możliwością driftowania. BMW - to znaczy, że masz wszystko na raz.',
                zh: '我们知道所有宝马爱好者的天堂。对于那些不想选择舒适、舒适和有能力的人来说。宝马如果你拥有所有和所有的东西',
            },
        },

        mercedes: {
            name: {
                ru: 'Мерсовод',
                ua: 'Мерсовод',
                en: 'Mercedes-Benz',
                de: 'Mercedes-Benz',
                pl: 'Mercedes-Benz',
                zh: '梅赛德斯奔驰',
            },
            desc: {
                ru: 'Mercedes-Benz это те машины которые действительно дают вам статус, комфорт и надёжность.',
                ua: 'Mercedes-Benz це ті машини, які дійсно дають вам статус, комфорт і надійність.',
                en: 'Mercedes-Benz are those cars that really give you status, comfort and reliability.',
                de: 'Mercedes-Benz sind die Autos, die dir wirklich Status, Komfort und Zuverlässigkeit bieten.',
                pl: 'Mercedes-Benz to samochody, które naprawdę zapewniają status, komfort i niezawodność.',
                zh: '梅赛德斯-奔驰是那些真正给你地位、舒适性和可靠性的汽车',
            },
        },

        japan: {
            name: {
                ru: 'Япошка',
                ua: 'Япошка',
                en: 'Japan',
                de: 'Japan',
                pl: 'Japan',
                zh: '日本',
            },
            desc: {
                ru: 'В этом кейсе собраны все японские автомобили, это те машины в которых есть душа.',
                ua: 'У цьому кейсі зібрані всі японські автомобілі, це ті машини, в яких є душа.',
                en: 'This case contains all Japanese cars, these are the cars that have soul in them.',
                de: 'Diese Kiste enthält alle japanischen Autos, das sind die Autos, die Seele haben.',
                pl: 'To etui zawiera wszystkie japońskie samochody, które mają w sobie duszę.',
                zh: '这些箱子里装的都是日本汽车，这些都是有灵魂的汽车',
            },
        },

        moto: {
            name: {
                ru: 'Мото',
                ua: 'Мото',
                en: 'Moto',
                de: 'Moto',
                pl: 'Moto',
                zh: '摩托车',
            },
            desc: {
                ru: 'Осознание любви к мотоциклам приходит не сразу, попробуй проехаться, и ты на всю жизнь окунулся в двухколесную культуру адреналина. Помни: 2 колеса возят душу, 4 колеса возят тушу.',
                ua: "Усвідомлення любові до мотоциклів приходить не одразу,спробуй проїхатись, і ти на все життя поринув у двоколісну культуру адреналіну. Пам'ятай: 2 колеса возять душу, 4 колеса возять тушу.",
                en: "Realizing a love for motorcycles doesn't come immediately, try a ride and you're plunged into a two-wheeled adrenaline culture for life. Remember: 2 wheels carry the soul, 4 wheels carry the carcass.",
                de: 'Das Gefühl fürs Motorradfahren lässt sich nicht sofort erklären - du musst es erleben. Setz dich drauf, fahr los, und es kann dein ganzes Leben verändern. Denk daran: Zwei Räder bewegen die Seele, vier Räder nur den Körper.',
                pl: 'Zrealizowanie miłosności do motocykli nie zaczyna się, sproboj jechć i znowu wchodze w twoję zycie. Znajdziesz: 2 kości prowadzą duch, 4 kości prowadzą głowe.',
                zh: '对摩托车的热爱不会立即得到认可，试着通过，你的一生都在两轮肾上腺素文化中度过。记住，两轮驱动灵魂，四轮驱动淋浴',
            },
        },

        workman: {
            name: {
                ru: 'Работяга',
                ua: 'Роботяга',
                en: 'Workman',
                de: 'Workman',
                pl: 'Workman',
                zh: '工人',
            },
            desc: {
                ua: 'Работягам треба дати відпочинок, в якості дару прийми цей кейс та звільни собі життя. P.S Арес',
                ru: 'Работягам надо дать отдых, в качестве дара прими этот кейс и освободи себе жизнь. P.S. Арес',
                en: 'Workers need to be given a break, accept this case as a gift and free your life. P.S Ares',
                de: 'Die Arbeitnehmer brauchen eine Pause, nimm diese Kiste als Geschenk und befreie dein Leben. P.S. Ares',
                pl: 'Pracownikom należy się przerwa, potraktuj tę sprawę jako prezent i uwolnij swoje życie. P.S. Ares',
                zh: '工人需要休息一下，把这个袋子，释放你的生命',
            },
        },

        major: {
            name: {
                ru: 'Мажор',
                ua: 'Мажор',
                en: 'Major',
                de: 'Major',
                pl: 'Major',
                zh: '少校',
            },
            desc: {
                ua: 'Мажори теж люди і їм треба багатіти,багатство приходить з досвідом, можливо саме сьогодні ти будеш у форбс? Або в тебе вдарить блискавка P.S Зевс.',
                ru: 'Мажоры тоже люди и им надо богатеть,богатство приходит с опытом, возможно именно сегодня ты будешь в форбс? Или в тебя ударит молния P.S. Зевс.',
                en: 'Majors are also people and they need to get rich, wealth comes with experience, maybe today you will be in Forbes? Or you will be struck by lightning P.S Zeus.',
                de: 'Majors sind auch Menschen, und sie müssen reich werden, und Reichtum kommt mit der Erfahrung, vielleicht wirst du heute in Forbes? Oder du wirst vom Blitz getroffen P.S. Zeus.',
                pl: 'Majorzy to też ludzie i muszą się bogacić, a bogactwo przychodzi z doświadczeniem, może dziś będziesz w Forbesie? Albo uderzy w ciebie piorun P.S Zeus.',
                zh: ' 专业人事也是人，他们必须致富，财富来自经验，也许今天你会在福布斯？',
            },
        },

        bussinesman: {
            name: {
                ru: 'Бизнесмен',
                ua: 'Бізнесмен',
                en: 'Businessman',
                de: 'Businessman',
                pl: 'Businessman',
                zh: '商人',
            },
            desc: {
                ru: 'Бизнесмену надо расширяться и вкладываться во что-то, боги рекомендуют инвестировать в деньги чтобы увеличить их запас. Сделай это и купи себе новые игрушки P.S Аполлон.',
                ua: 'Бізнесмену треба розширюватися та вкладатись у щось, боги рекомендують інвестувати у гроші щоб збільшити їх запас. Зроби це та купи собі нові цяцьки P.S Аполлон.',
                en: 'A businessman needs to expand and invest in something, the gods recommend investing in money to increase its supply. Do it and buy yourself some new P.S. Apollo chicks.',
                de: 'Ein Geschäftsmann muss expandieren und in etwas investieren, die Götter empfehlen, in Geld zu investieren, um sein Angebot zu erhöhen. Tu es und kaufe dur ein paar neue P.S. Apollo Chaps.',
                pl: 'Biznesmen musi się rozwijać i w coś inwestować, bogowie zalecają inwestowanie w pieniądze, aby zwiększyć ich podaż. Zrób to i kup sobie nowe czapki P.S. Apollo.',
                zh: '商人需要扩张和投资，上帝建议投资货币以增加供应',
            },
        },

        allOrNothing: {
            name: {
                ru: 'Все или ничего',
                ua: 'Все чи нічого',
                en: 'All or nothing',
                de: 'All or nothing',
                pl: 'All or nothing',
                zh: '一无所有或者赢下所有',
            },
            desc: {
                // ru: 'Только здесь ты сможешь попытать удачу, получишь ты всё или уйдёшь нисчем, зависит только от твоей удачи.',
                // ua: 'Тільки тут ти зможеш спробувати удачу, отримаєш ти все або підеш ні з чим, залежить тільки від твоєї удачі.',
                // en: 'Only here you can try luck, get you all or you will lose nothing, depends on your luck.',
                // de: 'Nur hier kannst du versuchen, Glück zu bekommen, dir alle oder du verlierst nichts. Dependiert von deinem Glück.',
                // pl: 'Tylko tutaj mozesz probowac udań, zyskasz wszystko lub stracisz nic, zalezy tylko od twojej udańosci.',
                ru: 'Сегодня Боги Олимпа дали тебе шанс, остаться голым босым или взойти на Олимп, используй этот шанс да докажи что ты достоин.',
                ua: 'Сьогодні Боги Олимпу дарували тобі шанс,лишитися голим босим або взійти на Олімп,використай цей шанс да доведи що ти гідний.',
                en: 'Today the Gods of Olymp gave you a chance to stay barefoot or climb Olympus, take this chance and prove yourself worthy.',
                de: 'Heute haben die Götter des Olymps dir die Chance gegeben, barfuß zu bleiben oder den Olymp zu besteigen. Nutze diese Chance und erweise dich als würdig.',
                pl: 'Dzisiaj Bogowie Olymp dali ci szansę pozostania boso lub wspięcia się na Olimp, skorzystaj z tej szansy i udowodnij, że jesteś tego godny.',
                zh: '只有在这里，你才能试试运气，得到一切或离开，这取决于你的运气',
            },
        },

        dasAuto: {
            name: {
                en: 'Das Auto',
            },

            desc: {
                ua: 'Німецький автопром один з найліпших у світі, комфорт, швидкість, якість - це все про них.',
                ru: 'Немецкий автопром один из самых лучших в мире, комфорт, скорость, качество - это все про них.',
                en: "German car industry is one of the best in the world, comfort, speed, quality - it's all about them.",
                de: 'Die deutsche Autoindustrie ist eine der besten der Welt: Komfort, Geschwindigkeit, Qualität - alles dreht sich um sie.',
                pl: 'Niemiecki auta - jeden z najlepszych w sferze, komfort, preśdkość, jakosść - to wszystko o nim.',
                zh: '德国的高速公路是世界上最好的高速公路之一，舒适、速度、质量都与它们有关',
            },
        },

        audi: {
            name: {
                ru: 'Властелин колец',
                ua: 'Володар Перснів',
                en: 'Audi',
                zh: '戒指',
                de: 'Audi',
            },

            desc: {
                ua: 'А чи не здається що при покупці AUDI легше знайти дівчину та почути фразу "Трусики знімати?"',
                ru: 'А не кажется ли что при покупке AUDI легче найти девушку и услышать фразу "Трусики снимать?"',
                en: `Doesn't it seem that when you buy an AUDI, it's easier to find a girl and hear the phrase "Shall I take off my underwear?"`,
                de: 'Scheint es nicht so, dass es leichter ist, ein Mädchen zu finden und den Satz "Soll ich meine Unterwäsche ausziehen?" zu hören, wenn man einen AUDI kauft?',
                pl: 'Nie widzisz, jak łatwiej jest znależć pani i słzić fraze "Czy moge zrobic sobie plecaki?"',
                zh: '当你买奥迪时，似乎更容易找到一个女孩，听到‘我可以脱下内衣吗',
            },
        },

        lambarghiniOrFerrari: {
            name: {
                ru: 'Ламба или Фера?',
                ua: 'Бик Чи Кінь?',
                en: 'Lamborghini or Ferrari?',
                zh: '兰博基尼还是法拉利',
                de: 'Lamborghini oder Ferrari?',
            },
            desc: {
                ua: 'А чи знали ви що недавно на гору Олімп завітали Ферруччо Ламборгіні та Енцо Феррарі доставивши нам контейнер своїх унікальних транспортних засобів які мають під капотом велику кількість конячок.',
                ru: 'А знали ли вы что недавно на гору Олимп посетили Ферруччо Ламборгини и Энцо Феррари доставив нам контейнер своих уникальных транспортных средств которые имеют под капотом большое количество лошадок.',
                en: 'Did you know that recently Ferruccio Lamborghini and Enzo Ferrari visited Mount Olymp and delivered us a container of their unique vehicles with a large number of horses under the hood?',
                zh: '你知道吗，最近在奥林匹斯山上，兰博基尼和恩佐·法拉利向我们运送了一个集装箱，里面装着他们独特的运输工具，里面有大量的马',
                de: 'Wusstest du, dass kürzlich Ferruccio Lamborghini und Enzo Ferrari den Olymp besucht und uns einen Container mit ihren einzigartigen Fahrzeugen geliefert haben - mit einer großen Anzahl Pferdestärken unter der Haube?',
            },
        },

        vehLuxury: {
            name: {
                ru: 'Роскошь',
                ua: 'Розкіш',
                en: 'Luxury',
                zh: '奢侈品',
            },

            desc: {
                ua: 'Ти любиш екзотичні машини? Тоді хочу представити неймовірно розкішні машини які стоять в гаражі Олімпу вже давно, та мало хто може їх собі дозволити.',
                ru: 'Ты любишь экзотические машины? Тогда хочу представить невероятно роскошные машины которые стоят в гараже Олимпа уже давно, но мало кто может их себе позволить.',
                en: 'Do you like exotic cars? Then I want to introduce incredibly luxurious cars that have been in the Olympus garage for a long time, but few people can afford them.',
                de: 'Magst du exotische Autos? Dann möchte ich dir unglaublich luxuriöse Autos vorstellen, die schon lange in der Olympus-Garage stehen, die sich aber nur wenige Menschen leisten können.',
                pl: 'Lubisz egzotyczne samochody? W takim razie chcę przedstawić niesamowicie luksusowe samochody, które od dawna znajdują się w garażu Olympus, ale niewielu ludzi może sobie na nie pozwolić.',
                zh: '你喜欢异国情调的汽车吗？然后，我想向您介绍在奥林巴斯车库里存放了很长时间的令人难以置信的豪华汽车，但只有少数人买得起',
            },
        },

        vehElite: {
            name: {
                ru: 'Элита Олимпа',
                ua: 'Еліта Олимпу',
                en: 'Elite Olymp',
                zh: '奥林匹克',
            },

            desc: {
                ru: 'На вершине горы Олимп находится тайный склад импортных автомобилей, в котором ты можешь найти редкие аппараты роскошного происхождения...',
                ua: 'На вершині гори Олімп знаходиться таємний склад імпортних автомобілів, у якому ти можеш знайти рідкісні апарати розкішного походження...',
                en: 'On the top of Mount Olympus there is a secret warehouse of imported cars, where you can find rare vehicles of luxury origin...',
                de: 'Auf dem Gipfel des Olymp gibt es ein geheimes Lager für importierte Autos, in dem man seltene Luxusautos finden kann...',
                pl: 'Na szczycie Olimpu znajduje się tajny magazyn importowanych samochodów, w którym można znaleźć rzadkie luksusowe samochody....',
                zh: '奥林匹克峰会有一个秘密的进口汽车仓库，你可以在里面找到稀有的豪华汽车',
            },
        },

        vehMedium: {
            name: {
                ru: 'Средний класс',
                ua: 'Середний клас',
                en: 'Medium class',
                zh: '中等阶级',
            },

            desc: {
                ru: 'Средний класс автопрома, однако всё ещё имеет очень достойные экземляры машин.',
                ua: 'Середній клас автопрому, проте все ще має дуже гідні екземпляри машин.',
                en: 'Middle class car industry, but still has very decent examples of cars.',
                de: 'Die Mittelklasse der Autoindustrie, hat aber immer noch sehr anständige Beispiele von Autos.',
                pl: 'Klasa średnia przemysłu samochodowego, ale wciąż ma bardzo przyzwoite przykłady samochodów.',
                zh: '汽车行业的中产阶级，但仍然有非常不错的汽车例子',
            },
        },

        vehLow: {
            name: {
                ru: 'Низкий класс',
                ua: 'Низький клас',
                en: 'Low class',
                zh: '等级低',
            },

            desc: {
                ua: 'К вашій увазі - древні колісниці на яких в давні часи їздили боги.',
                ru: 'К вашему вниманию - древние колесницы на которых в давние времена ездили боги.',
                en: 'We bring to your attention the ancient chariots used by the gods in ancient times.',
                de: 'Wir machen dich auf die antiken Streitwagen aufmerksam, die von den Göttern in der Antike benutzt wurden.',
                pl: 'Zwracamy uwagę na starożytne rydwany używane przez bogów w czasach starożytnych.',
                zh: '你的注意力集中在众神早已离开的古老圈子里',
            },
        },

        zeus: {
            name: {
                ru: 'Зевс',
                ua: 'Зевс',
                en: 'Zeus',
                zh: '宙斯',
            },

            desc: {
                ru: 'Здесь собран легендарный воздушный транспорт, воплощение мощи и стиля самого великого бога, Зевса. Попытай удачу и получи мощные самолеты и элегантные вертолеты, готовые взлететь в небеса и подарить вам незабываемые ощущения свободы и могущества.',
                ua: 'Тут зібрано легендарний повітряний транспорт, втілення могутності та стилю найвеличнішого бога, Зевса. Спробуй удачу й отримай потужні літаки та елегантні гелікоптери, готові злетіти в небеса й подарувати вам незабутні відчуття свободи та могутності.',
                en: 'Here is a collection of legendary air transportation, the embodiment of the power and style of the greatest god himself, Zeus. Try your luck and get powerful airplanes and elegant helicopters ready to take to the skies and give you unforgettable feelings of freedom and power.',
                de: 'Hier ist eine Sammlung von legendären Lufttransportmitteln, die die Macht und den Stil des großen Gottes Zeus verkörpern. Versuche dein Glück und hol dir leistungsstarke Flugzeuge und elegante Hubschrauber, die bereit sind, sich in die Lüfte zu erheben und dir unvergessliche Gefühle von Freiheit und Macht zu geben.',
                pl: 'Oto kolekcja legendarnych środków transportu powietrznego, będących ucieleśnieniem potęgi i stylu samego wielkiego boga, Zeusa. Spróbuj szczęścia i zdobądź potężne samoloty i eleganckie helikoptery gotowe wzbić się w przestworza i dać ci niezapomniane poczucie wolności i władzy.',
            },
        },

        poseidon: {
            name: {
                ru: 'Посейдон',
                ua: 'Посейдон',
                en: 'Poseidon',
                de: 'Poseidon',
            },

            desc: {
                ua: 'Навідати володаря морів і океанів, Посейдона можна лише маючи один з цих апаратів, але будь обережним не потопись намагаючись його побачити, одна найменша помилка та ти побачиш не посейдона, а свого творця.',
                ru: 'Навестить повелителя морей и океанов, Посейдона можно лишь имея один из этих аппаратов, но будь осторожным не утонись пытаясь его увидеть, одна малейшая ошибка и ты увидишь не посейдона, а своего создателя.',
                en: 'You can only visit the lord of the seas and oceans, Poseidon, if you have one of these devices, but be careful not to drown trying to see him, one slightest mistake and you will see not Poseidon, but your creator.',
                de: 'Du kannst den Herrn der Meere und Ozeane, Poseidon, nur besuchen, wenn du eines dieser Geräte hast. Aber pass auf, dass du nicht ertrinkst, wenn du versuchst, ihn zu sehen, denn ein kleiner Fehler und du wirst nicht Poseidon sehen, sondern deinen Schöpfer.',
                pl: 'Możesz odwiedzić władcę mórz i oceanów, Posejdona, tylko jeśli masz jedno z tych urządzeń, ale uważaj, aby nie utonąć próbując go zobaczyć, jeden najmniejszy błąd i nie zobaczysz Posejdona, ale swojego stwórcę.',
                zh: '这是一组传奇的航空运输作品，体现了最伟大的神宙斯本人的力量和风格。试试你的运气，让强大的飞机和优雅的直升机准备好飞向天空，给你难忘的自由和力量的感觉',
            },
        },

        pandora: {
            name: {
                ru: 'Пандора',
                ua: 'Пандора',
                en: 'Pandora',
                de: 'Pandora',
                zh: '潘多拉',
            },

            desc: {
                ru: 'Этот кейс полный разных сокровищ, словно легенда оживает. Вдохновленный мифом о первой женщине, этот кейс скрывает разнообразие от великолепных автомобилей до редких предметов и опыта. Но будьте осторожны: как и в мифе, здесь могут быть и разочарования, и обыденные предметы, напоминая о цене великих сокровищ.',
                ua: 'Цей кейс повний різних скарбів, немов легенда оживає. Натхненний міфом про першу жінку, цей кейс приховує розмаїття: від чудових автівок до рідкісних предметів і досвіду. Але будьте обережні: як і в міфі, тут можуть бути і розчарування, і буденні предмети, нагадуючи про ціну великих скарбів.',
                en: 'This case full of different treasures is like a legend come to life. Inspired by the myth of the first woman, this case hides a variety from magnificent cars to rare items and experiences. But beware: like the myth, there can be disappointments and mundane items, reminding you of the price of great treasures.',
                de: 'Dieser Koffer voller verschiedener Schätze ist wie eine lebendig gewordene Legende. Inspiriert vom Mythos der ersten Frau, verbirgt dieser Koffer eine Vielfalt von prächtigen Autos bis hin zu seltenen Gegenständen und Erfahrungen. Aber Vorsicht: Wie der Mythos kann es Enttäuschungen und banale Gegenstände geben, die dich an den Preis großer Schätze erinnern.',
                pl: 'Ta walizka pełna różnych skarbów jest jak legenda, która ożyła. Zainspirowany mitem o pierwszej kobiecie, ten futerał kryje w sobie różnorodność, od wspaniałych samochodów po rzadkie przedmioty i doświadczenia. Ale uwaga: podobnie jak w micie, mogą pojawić się rozczarowania i przyziemne przedmioty, przypominające o cenie wielkich skarbów.',
                zh: '这个袋子里装满了各种各样的珍宝，就像一个活生生的传说。受第一位女性神话的启发，这个案例隐藏了多样性：从伟大的汽车到稀有的物品和体验。但要小心：就像神话中一样，可能会有失望和即将发生的事情，提醒我们珍宝的价格',
            },
        },

        stickers: {
            name: {
                ru: 'Наклейки',
                ua: 'Наліпки',
                en: 'Stickers',
                de: 'Aufkleber',
                pl: 'Naklejki',
                zh: '贴纸',
            },

            desc: {
                ru: 'Кейс с наклейками для кастомного винила. Внутри - закрытые наклейки: часть из них продаётся в ателье за коины, а часть можно получить только отсюда. Выпавшая наклейка ждёт на донат-складе, а в ателье первый слой с ней ставится на машину бесплатно, и дальше её можно двигать, красить и повторять сколько угодно раз.',
                ua: 'Кейс із наліпками для кастомного вінілу. Усередині - закриті наліпки: частина з них продається в ательє за коїни, а частину можна отримати лише звідси. Наліпка, що випала, чекає на донат-складі, а в ательє перший шар із нею встановлюється на авто безкоштовно, і далі її можна рухати, фарбувати й повторювати скільки завгодно разів.',
                en: 'A case of stickers for custom vinyl. Inside are the locked ones: some are sold at the workshop for coins, others come only from here. The sticker waits in the donate warehouse, and at the workshop its first layer goes on the car for free - after that you can move it, tint it and repeat it as often as you like.',
                de: 'Eine Kiste mit Aufklebern für individuelles Vinyl. Darin stecken die gesperrten: Manche verkauft die Werkstatt für Coins, andere gibt es nur hier. Der Aufkleber wartet im Spendenlager, und in der Werkstatt kommt seine erste Ebene gratis aufs Auto - danach kannst du sie verschieben, einfärben und beliebig oft wiederholen.',
                pl: 'Skrzynka z naklejkami do własnego winylu. W środku są te zablokowane: część sprzedaje warsztat za coiny, a część zdobędziesz tylko tutaj. Naklejka czeka w magazynie donate, a w warsztacie jej pierwsza warstwa trafia na auto za darmo - potem możesz ją przesuwać, barwić i powtarzać dowolną liczbę razy.',
                zh: '自定义车贴用的贴纸箱子。里面是锁定的贴纸：一部分可在改装店用金币购买，另一部分只能从这里获得。抽到的贴纸存放在捐赠仓库，在改装店中它的第一个图层免费贴到车上，之后可以随意移动、上色并重复使用。',
            },
        },

        tuner: {
            name: {
                ru: 'Тюнер',
                ua: 'Тюнер',
                en: 'Tuner',
                de: 'Tuner',
                pl: 'Tuner',
                zh: '改装师',
            },

            desc: {
                ru: 'Кейс для тех, кто собирает машину под себя. Внутри - обвесы, чипы Stage 1, 2, 3 и Drift и диски Olymp Design, которых нет в продаже в ателье: многие из них можно получить только отсюда. Выпавший предмет ждёт на донат-складе и ставится в тюнинг-ателье. Обвес подходит своей модели, чип - машине с чип-тюнингом, диск - любой машине.',
                ua: 'Кейс для тих, хто збирає авто під себе. Всередині - обвіси, чипи Stage 1, 2, 3 та Drift і диски Olymp Design, яких немає у продажу в ательє: багато з них можна отримати лише звідси. Предмет, що випав, чекає на донат-складі та встановлюється в тюнінг-ательє. Обвіс підходить своїй моделі, чип - авто з чип-тюнінгом, диск - будь-якому авто.',
                en: 'A case for those who build a car their own way. Inside are body kits, Stage 1, 2, 3 and Drift chips and Olymp Design wheels the workshop does not sell: many of them come only from here. A prize waits in the donate warehouse and is installed at the tuning workshop. A body kit fits its own model, a chip fits a car with chip tuning, a wheel fits any car.',
                de: 'Eine Kiste für alle, die ihr Auto nach eigenem Geschmack aufbauen. Darin stecken Bodykits, Chips Stage 1, 2, 3 und Drift und Olymp-Design-Felgen, die die Werkstatt nicht verkauft: Viele davon gibt es nur hier. Ein Gewinn wartet im Spendenlager und wird in der Tuning-Werkstatt eingebaut. Ein Bodykit passt zu seinem Modell, ein Chip zu einem Auto mit Chiptuning, eine Felge auf jedes Auto.',
                pl: 'Skrzynka dla tych, którzy budują auto po swojemu. W środku body kity, chipy Stage 1, 2, 3 i Drift oraz felgi Olymp Design, których warsztat nie sprzedaje: wiele z nich zdobędziesz tylko tutaj. Wygrany przedmiot czeka w magazynie donate i montuje się go w warsztacie tuningowym. Body kit pasuje do swojego modelu, chip - do auta z chip tuningiem, felga - do każdego auta.',
                zh: '为按自己想法打造座驾的玩家准备的箱子。里面有车身套件、Stage 1、2、3 和 Drift 芯片，以及改装店不出售的 Olymp Design 轮毂：其中许多只能从这里获得。抽到的物品存放在捐赠仓库，在改装店安装。车身套件适用于对应车型，芯片适用于支持芯片改装的车辆，轮毂适用于任何车辆。',
            },
        },

        autoExpert: {
            name: {
                ru: 'Автоэксперт',
                ua: 'Автоэксперт',
                en: 'Autoexpert',
                de: 'Autoexperte',
                zh: '汽车专家',
            },

            desc: {
                ru: 'Здесь собраны машины всех категорий, от самых доступных до роскошных экземпляров, чтобы удовлетворить даже самые изысканные вкусы и требования.',
                ua: 'Тут зібрані машини всіх категорій, від найдоступніших до розкішних екземплярів, щоб задовольнити навіть найвишуканіші смаки і вимоги.',
                en: 'There are cars from all categories, from the most affordable to the most luxurious specimens, to satisfy even the most refined tastes and requirements.',
                de: 'Es gibt Autos aller Kategorien, von den erschwinglichsten bis hin zu den luxuriösesten Exemplaren, die auch die anspruchsvollsten Geschmäcker und Anforderungen erfüllen.',
                pl: 'Istnieją samochody wszystkich kategorii, od najbardziej przystępnych cenowo po najbardziej luksusowe okazy, które zaspokoją nawet najbardziej wyrafinowane gusta i wymagania.',
                zh: '有各种类型的汽车，从最实惠的价格到最豪华的功能，甚至可以满足最精致的品味和要求',
            },
        },

        dailyCase: {
            name: {
                ru: 'Ежедневный кейс',
                ua: 'Щоденний кейс',
                en: 'Daily Case',
                de: 'Tägliche Kiste',
                pl: 'Codzienna Skrzynka',
            },
            desc: {
                ru: 'Этот кейс нельзя купить, но вы можете получать его каждый день абсолютно бесплатно просто играя на проекте!',
                ua: 'Цей кейс неможливо придбати, але ви можете отримувати його кожного дня абсолютно безкоштовно, просто граючи на проєкті!',
                en: 'This case cannot be bought, but you can receive it every day absolutely free just by playing on the project!',
                de: 'Diese Kiste kann nicht gekauft werden, aber du kannst ihn jeden Tag völlig kostenlos erhalten, indem du einfach auf dem Projekt spielen!',
                pl: 'Tego pudełka nie można kupić, ale możesz je otrzymać codziennie, zupełnie za darmo, po prostu grając na projekcie!',
            },
            leftToPlay: {
                ru: 'Отыграть осталось',
                ua: 'Залишилося відіграти',
                en: 'Left to play',
                de: 'Verbleibend zu spielen',
                pl: 'Pozostało do zagrania',
            },

            received: {
                ru: 'Получено',
                ua: 'Отримано',
                en: 'Received',
                de: 'Erhalten',
                pl: 'Otrzymano',
            },

            receivedTitle: {
                ru: 'Вы получили Ежедневный кейс!',
                ua: 'Ви отримали Щоденний кейс!',
                en: 'You received a Daily Case!',
                de: 'Du hast eine tägliche Kiste erhalten!',
                pl: 'Otrzymałeś codzienną skrzynię!',
            },

            receivedDesc: {
                ru: 'Поздравляем! Вы отыграли необходимое количество времени и получили Ежедневный кейс, открыть его можно в Меню > Магазин > Склад',
                ua: 'Вітаємо! Ви відіграли необхідну кількість часу та отримали Щоденний кейс, відкрити його можна в Меню > Магазин > Склад',
                en: 'Congratulations! You have played the required amount of time and received a Daily Case, you can open it in Menu > Shop > Inventory',
                de: 'Herzlichen Glückwunsch! Du hast die erforderliche Zeit gespielt und eine tägliche Kiste erhalten, diese kannst du im Menü > Shop > Inventar öffnen',
                pl: 'Gratulacje! Rozegrałeś wymaganą ilość czasu i otrzymałeś codzienną skrzynię, możesz ją otworzyć w Menu > Sklep > Magazyn',
            },
        },

        newYear: {
            name: {
                ru: 'Новогодний кейс',
                ua: 'Новорічний кейс',
                en: 'New Year Case',
                de: 'Neujahrsfall',
                pl: 'Noworoczna skrzynia',
            },
            desc: {
                ru: 'В этом кейсе собрана уникальная одежда, которую нельзя купить в магазине, а также другие ценные призы. Собирайте конфеты, разбросанные по всей карте, и обменивайте их у Санты на этот кейс! С Новым Годом!',
                ua: 'У цьому кейсі зібрано унікальний одяг, який не можна купити в магазині, а також інші цінні призи. Збирайте цукерки, розкидані по всій карті, та обмінюйте їх у Санти на цей кейс! З Новим Роком!',
                en: 'This case contains unique clothing that cannot be purchased in the store, as well as other valuable prizes. Collect candies scattered across the map and exchange them with Santa for this case! Happy New Year!',
                de: 'In diesem Fall gibt es einzigartige Kleidung, die nicht im Laden gekauft werden kann, sowie andere wertvolle Preise. Sammle Süßigkeiten, die über die ganze Karte verstreut sind, und tausche sie bei Santa gegen diesen Koffer ein! Frohes neues Jahr!',
                pl: 'W tym pudełku znajduje się unikalna odzież, której nie można kupić w sklepie, oraz inne cenne nagrody. Zbieraj cukierki rozrzucone po całej mapie i wymieniaj je u Świętego Mikołaja na to pudełko! Szczęśliwego Nowego Roku!',
            },
        },

        armourCase: {
            name: {
                ru: 'Бронежилеты',
                ua: 'Бронежилети',
                en: 'Armour Vests',
                de: 'Panzerweste',
                pl: 'Kamizelki kuloodporne',
            },
            desc: {
                ru: 'В этом кейсе вы можете попытать свою удачу выбив уникальный скин для вашего бронежилета.',
                ua: 'У цьому кейсі ви можете спробувати свою удачу, вибивши унікальний скін для вашого бронежилета.',
                en: 'In this case, you can try your luck and get a unique skin for your armour vest.',
                de: 'In dieser Kiste kannst du dein Glück versuchen und einen einzigartigen Skin für deine Panzerweste erhalten.',
                pl: 'W tym przypadku możesz spróbować szczęścia i zdobyć unikalny skin dla swojej kamizelki kuloodpornej.',
            },
        },

        summer2026: {
            name: {
                ru: 'Лето 2026',
                ua: 'Літо 2026',
                en: 'Summer 2026',
                de: 'Sommer 2026',
                pl: 'Lato 2026',
            },
            desc: {
                ru: 'Кейс из первого боевого пропуска на проекте. Внутри собраны эксклюзивные награды Олимпа: уникальная одежда, татуировки, скины оружия и брони, а также танцевальные анимации.',
                ua: 'Кейс із першого бойового пропуску на проєкті. Усередині зібрані ексклюзивні нагороди Олімпу: унікальний одяг, татуювання, скіни зброї та броні, а також танцювальні анімації.',
                en: 'A case from the first battle pass on the project. Inside you will find the exclusive rewards of Olymp: unique clothing, tattoos, weapon and armour skins, as well as dance animations.',
                de: 'Eine Kiste aus dem ersten Battle Pass auf dem Projekt. Darin findest du die exklusiven Belohnungen des Olymps: einzigartige Kleidung, Tattoos, Waffen und Rüstungsskins sowie Tanzanimationen.',
                pl: 'Skrzynia z pierwszego Battle Pass na projekcie. W środku znajdziesz ekskluzywne nagrody Olimpu: unikalne ubrania, tatuaże, skiny broni i kamizelek oraz animacje taneczne.',
            },
        },
    },

    openingDesc: {
        desc1: {
            ru: 'Удачи!',
            ua: 'Вдачи!',
            en: 'Good luck!',
            de: 'Viel Glück!',
            pl: 'Dobrze!',
            zh: '祝你好运:',
        },

        desc2: {
            ru: 'Что же выпадет?',
            ua: 'Що же випаде?',
            en: 'What will drop?',
            de: 'Was wird fallen?',
            pl: 'Co zyje?',
            zh: '会发生什么',
        },

        desc3: {
            ru: 'Еще один кейс?',
            ua: 'Ще один кейс?',
            en: 'Another case?',
            de: 'Weitere Kiste?',
            pl: 'Jeszcze jedna skrzynka?',
            zh: '另一个盒子',
        },

        desc4: {
            ru: 'Кто знает, что скрывается за этим замком?',
            ua: 'Хто знає, що ховається за цим замком?',
            en: 'Who knows what is hidden behind this lock?',
            de: 'Wer weiß, was versteckt ist, hinter dieser Tuer?',
            pl: 'Kto dowiedziec się, co jest ukryte pod tym zamkiem?',
            zh: '谁知道这把锁后面藏着什么',
        },

        desc5: {
            ru: 'Всё или ничего?',
            ua: 'Все чи нічого?',
            en: 'All or nothing?',
            de: 'Alles oder nichts?',
            pl: 'Wszystko lub nic?',
            zh: '有什么还是什么都没有？',
        },

        desc6: {
            ru: 'Напряжение нарастает...',
            ua: 'Напруга зростає...',
            en: 'Voltage rises...',
            de: 'Spannung steigt...',
            pl: 'Niskie napiecie...',
            zh: '紧张局势越来越严重',
        },

        desc7: {
            ru: 'Удача любит смелых!',
            ua: 'Удача любить сміливих!',
            en: 'Luck loves the brave!',
            de: 'Glück liebt die Mutigen!',
            pl: 'Dobrze, miłosny!',
            zh: '运气喜欢勇敢的人！',
        },

        desc8: {
            ru: 'Главное - верить в чудо!',
            ua: 'Головне - вірити в диво!',
            en: 'Main - believe in the wonder!',
            de: 'Hauptsache - glaub an das Wunder!',
            pl: 'Glowne - poczynaj swobodnie!',
            zh: '主要是相信奇迹！',
        },

        desc9: {
            ru: 'Какой приз тебя ждёт сегодня?',
            ua: 'Який приз на тебе чекає сьогодні?',
            en: 'Which prize awaits you today?',
            de: 'Welcher Preis steht dir heut vor?',
            pl: 'Co zyje dzisiaj?',
            zh: '今天有什么惊喜?',
        },

        desc10: {
            ru: 'Верь в свою удачу!',
            ua: 'Вір у свою удачу!',
            en: 'Believe in your luck!',
            de: 'Glaube in deine Glücke!',
            pl: 'Poczynaj swobodnie!',
            zh: '相信你的运气！',
        },

        desc11: {
            ru: 'Почти миллионер(ша)!',
            ua: 'Майже мільйонер(ша)!',
            en: 'Almost millionaire!',
            de: 'Niemals Millionär!',
            pl: 'Jednak nie milioner!',
            zh: '但不是百万富翁！',
        },

        desc12: {
            ru: 'Кто не рискует тот не пьет шампанского!',
            ua: "Хто не ризикує той не п'є шампанського!",
            en: "He who doesn't take risks doesn't drink champagne!",
            de: 'Wer nicht wagt, der nicht gewinnt!',
            pl: 'Kto nie ma ryzyka, nie picie piwa!',
            zh: '谁不冒险喝香槟呢！',
        },

        desc13: {
            ru: 'Кто не играет тот не выигрывает!',
            ua: 'Хто не грає той не виграє!',
            en: "He who doesn't play doesn't win!",
            de: 'Wer nicht spielt, kann nicht Siegen!',
            pl: 'Kto nie gra, nie wygrywa!',
            zh: '不打球的人不会赢',
        },

        desc14: {
            ru: 'Может быть в этот раз повезёт?',
            ua: 'Можливо, цього разу пощастить?',
            en: "Maybe this time we'll get lucky.",
            de: 'Vielleicht, das mal mit Glücken.',
            pl: 'Może to zatem zyc!',
            zh: '也许这次我们会走运',
        },

        desc15: {
            ru: 'Удача переменчива, но сегодня она может стать твоей!',
            ua: 'Удача мінлива, але сьогодні вона може стати твоєю!',
            en: 'Luck is unpredictable, but today it may be yours!',
            de: 'Glück ist unberechenbar, aber heute ist es deins!',
            pl: 'Dobrze jest zmienna, ale dzisiaj jest twoja!',
            zh: '运气是不可预测的，但今天它可能是你的！',
        },

        desc16: {
            ru: 'Может быть выпадет {{prize1}} ну или хотя бы {{prize2}} ?',
            ua: 'Можливо, випаде {{prize1}} ну або хоча б {{prize2}} ?',
            en: 'Maybe it will drop {{prize1}} or at least {{prize2}} ?',
            de: 'Vielleicht wird es {{prize1}} oder mindestens {{prize2}} fallen ?',
            pl: 'Može, zyje {{prize1}} lub co najmniej {{prize2}}?',
            zh: '这可能是好的，还是至少是好的？',
        },

        desc17: {
            ru: '{{prize1}} так близко и так далеко...',
            ua: '{{prize1}} так близько і так далеко...',
            en: '{{prize1}} so close and so far...',
            de: '{{prize1}} so nah und so weit...',
            pl: '{{prize1}} tak blisko i tak daleko...',
            zh: '这么近，这么远',
        },

        desc18: {
            ru: 'Может быть именно в этот раз тебе выпадет {{prize1}} ?',
            ua: 'Можливо, саме цього разу тобі випаде {{prize1}} ?',
            en: "Maybe this time we'll get {{prize1}} ?",
            de: 'Vielleicht, das mal mit {{prize1}} fallen?',
            pl: 'Može to zatem zyc {{prize1}}?',
            zh: '也许这就是你获得奖项的时候了？',
        },

        desc19: {
            ru: 'Представь как тебе все будут завидовать когда ты выиграешь {{prize1}} !',
            ua: 'Уяви як тобі всі будуть заздрити коли ти виграєш {{prize1}} !',
            en: 'Imagine how jealous everyone will be when you win {{prize1}} !',
            de: 'Vergiss nicht, dass alle neidisch auf dich sein werden, wenn du {{prize1}} gewinnst!',
            pl: 'Zastap sobie jak wszystkie beznadzienia, kiedy wygrywasz {{prize1}} !',
            zh: '想象一下，当你获胜时，每个人都会感到惊讶',
        },

        desc20: {
            ru: 'Тебе выпадет {{yourPrize}}, поверил? а может быть я шучу...',
            ua: 'Тобі випаде {{yourPrize}}, повірив? а може я жартую...',
            en: "You're gonna get {{yourPrize}}, believe it? Or maybe I'm just kidding....",
            de: 'Du erhältst {{yourPrize}}, glaubst du mir? Oder mache ich nur Späße...',
            pl: 'Wyjdzie {{yourPrize}}, czy jestes pewny? lub cos nie wiem...',
            zh: '你的奖品是什么？',
        },
    },
};
